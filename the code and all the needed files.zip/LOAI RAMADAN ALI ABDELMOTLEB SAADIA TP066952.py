# LOAI_RAMADAN_ALI_ABDELMOTLEB_SAADIA
# TP066952

import datetime


def hospital(index,itemCode,itemQuantity):
    list_H = open("hospitals.txt","r").readlines()
    list_H[index] = list_H[index].strip().split(",")
    if itemCode == "HC":
        list_H[index][2] = str(int(list_H[index][2]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    elif itemCode == "FS":
        list_H[index][4] = str(int(list_H[index][4]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    elif itemCode == "MS":
        list_H[index][6] = str(int(list_H[index][6]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    elif itemCode == "GL":
        list_H[index][8] = str(int(list_H[index][8]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    elif itemCode == "GW":
        list_H[index][10] = str(int(list_H[index][10]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    elif itemCode == "SC":
        list_H[index][12] = str(int(list_H[index][12]) +int(itemQuantity))
        list_H[index] = ",".join(list_H[index])+"\n"
    h_l = open("hospitals.txt","w")
    h_l.writelines(list_H)
    h_l.close

def update():
    choiceUpdate = False
    while choiceUpdate == False:
        print("""
    ( 1 )Add Items 
    ( 2 )Take Items
    ( 3 )Back
        """)
        choice = input("\nPlease enter choice: ")
        if choice == "1" or choice  == "2" or choice == "3" :
            if choice == "1":
                item = False
                while item == False:
                    itemCode = input("\nEnter Item Code: ")
                    if itemCode == "HC" or itemCode == "FS" or itemCode == "MS" or itemCode == "GL" or itemCode == "GW" or itemCode == "GL" or itemCode == "SC":
                        item = True
                    else:
                        print("\nincoreect code")
                suppleir = False
                while suppleir ==False:
                            suppleir_code = input("\nenter your Supplier code: ")
                            if suppleir_code == "SUP11" or suppleir_code == "SUP22" or suppleir_code == "SUP33":
                                if suppleir_code == "SUP11":
                                    if itemCode == "HC" or itemCode == "FS":
                                        suppleir = True
                                    else:
                                        print("\nincorrect Supplier Code")
                                elif suppleir_code == "SUP22":
                                    if itemCode == "MS" or itemCode == "GL":
                                        suppleir = True
                                    else:
                                        print("\nincorrect Supplier Code")
                                elif suppleir_code == "SUP33":
                                    if itemCode == "GW" or itemCode == "SC":
                                        suppleir = True
                                    else:
                                        print("\nincorrect Supplier Code")
                            else :
                                print("\nincorrect Code")
                quantity = False
                while quantity == False:
                    itemQuantity = input("\nenter quantity: ")
                    if itemQuantity.isnumeric() == True:
                        quantity = True
                    else:
                        print("\nplease put a number")
                list = open("ppe.txt","r").readlines()
                count = 0
                for index in list :
                    index = index.strip().split(",")
                    if index[0] == itemCode:
                        index[2] = str(int(index[2])+int(itemQuantity))+"\n"
                        newLine = ",".join(index)
                        list[count] = newLine
                    count +=1
                file = open("ppe.txt","w")
                file.writelines(list)
                file.close
                list_S= open("supplier.txt","r").readlines()
                if suppleir_code == "SUP11":
                    list_S[0] = list_S[0].strip().split(",")
                    if itemCode == "HC":
                        list_S[0][2] = str(int(list_S[0][2]) +int(itemQuantity))
                        list_S[0] = ",".join(list_S[0])+"\n"
                    elif itemCode == "FS":
                        list_S[0][4] = str(int(list_S[0][4]) +int(itemQuantity))
                        list_S[0] = ",".join(list_S[0])+"\n"
                elif suppleir_code == "SUP22":
                    list_S[1] = list_S[1].strip().split(",")
                    if itemCode == "MS":
                        list_S[1][2] = str(int(list_S[1][2]) +int(itemQuantity))
                        list_S[1] = ",".join(list_S[1])+"\n"
                    elif itemCode == "GL":
                        list_S[1][4] = str(int(list_S[1][4]) +int(itemQuantity))
                        list_S[1] = ",".join(list_S[1])+"\n"
                elif suppleir_code == "SUP33":
                    list_S[2] = list_S[2].strip().split(",")
                    if itemCode == "GW":
                        list_S[2][2] = str(int(list_S[2][2]) +int(itemQuantity))
                        list_S[2] = ",".join(list_S[2])+"\n"
                    elif itemCode == "SC":
                        list_S[2][4] = str(int(list_S[2][4]) +int(itemQuantity))
                        list_S[2] = ",".join(list_S[2])+"\n"
                list_z = open("supplier.txt","w")
                list_z.writelines(list_S)
                list_z.close
                dates = str(datetime.date.today())
                dist = open("distribution.txt","a")
                dist.write("\n"+suppleir_code+","+itemCode+","+itemQuantity+","+dates)
                dist.close
                choiceUpdate = True
            elif choice == "2":
                hospitalCode = False
                while hospitalCode == False:
                    hospital_input = input("\nEnter Hospital Code: ")
                    if hospital_input == "HOS11" or hospital_input == "HOS22" or hospital_input == "HOS33":
                        hospitalCode = True
                    else :
                        print("\nincorrect Hospital Code")
                itemCode4HOS = False
                while itemCode4HOS == False:
                    itemCode = input("\nEnter Item Code: ")
                    if itemCode == "HC" or itemCode == "FS" or itemCode == "MS" or itemCode == "GL" or itemCode == "GW" or itemCode == "GL" or itemCode == "SC":
                        itemCode4HOS = True
                    else :
                        print("\nIncorrect Code")
                correct = False
                while correct == False:
                    itemQuantity = input("\nenter quantity: ")
                    if itemQuantity.isnumeric() == True:
                        correct = True
                    else:
                        print("pleas put a numper!!")
                list = open("ppe.txt","r").readlines()
                count = 0
                for index in list :
                    index = index.strip().split(",")
                    if index[0] == itemCode:
                        if (int(index[2])-int(itemQuantity)) >= 0: 
                            index[2] = str(int(index[2])-int(itemQuantity))+"\n"
                            newLine = ",".join(index)
                            list[count] = newLine
                            if hospital_input == "HOS11":
                                hospital(0,itemCode,itemQuantity)
                            elif hospital_input == "HOS22":
                                hospital(1,itemCode,itemQuantity)
                            elif hospital_input == "HOS33":
                                hospital(2,itemCode,itemQuantity)
                            dates = str(datetime.date.today())
                            dist_hos = open("distribution.txt","a")
                            dist_hos.write("\n"+hospital_input+","+itemCode+","+itemQuantity+","+dates)
                            dist_hos.close
                        else:
                            print("You have "+index[2]+". You cannot take "+itemQuantity)
                    choiceUpdate = False
                    count+=1
                    file = open("ppe.txt","w")
                    file.writelines(list)
                    file.close
                choiceUpdate = True
            elif choice == "3":
                choiceUpdate = True
        else:
            print("\nIncorrect input!")
            
def search():
    file_s = open("supplier.txt","r").readlines()
    file_h = open("hospitals.txt","r").readlines()
    file_d = open("distribution.txt","r").readlines()
    ChoiceSearch = False
    while ChoiceSearch == False:
        print("""
        ( 1 ) Search By Supplier Code
        ( 2 ) Search By Hospital Code
        ( 3 ) Search By Item Code
        ( 4 ) Back
        """)
        choice = input("\ntype your Choice: ")
        if choice =="1":
            sup = False
            while sup == False:
                SupplierCode = input("\nEnter Your Supplier Code: ")
                if SupplierCode == "SUP11" or SupplierCode == "SUP22" or SupplierCode == "SUP33":
                    sup = True
                else:
                    print ("Incorrect Supplier Code!")
            for index in file_d:
                index = index.strip().split(",")
                if index[0] == SupplierCode:
                    print("\n"+index[0] + " added " + index[2] + " of " + index[1] + " at " + index[3])
            for index in file_s:
                index = index.strip().split(",")
                if index[0] == SupplierCode:
                    print("\n"+index[0] + " gave in total " + index[2] + " of " + index[1] + " and " + index[4]+ " of " + index[3])
        elif choice == "2":
            hos = False
            while hos == False:
                HospitalCode = input("\nEnter Your Hospital Code: ")
                if HospitalCode == "HOS11" or HospitalCode == "HOS22" or HospitalCode == "HOS33":
                    hos = True
                else:
                    print ("Incorrect Hospital Code!!")
            for index in file_d:
                index = index.strip().split(",")
                if index[0] == HospitalCode:
                    print("\n"+index[0] + " took " + index[2] + " of " + index[1] + " at " + index[3])
            for index in file_h:
                index = index.strip().split(",")
                if index[0] == HospitalCode:
                    print("\n"+index[0] + " has " + index[1] + ": " + index[2] , index[3] + ": " + index[4] , index[5] + ": " + index[6] , index[7] + ": " + index[8] , index[9] + ": " + index[10] , index[11] + ": " + index[12])
        elif choice == "3":
            item = False
            while item == False:
                itemCode = input("\nEnter Your Item Code: ")
                if itemCode == "HC" or itemCode == "FS" or itemCode == "MS" or itemCode == "GL" or itemCode == "SC" or itemCode == "GW":
                    item = True
                else :
                    print ("Incorrect Item Code!!")
            for index in file_d:
                index = index.strip().split(",")
                if index[1] == itemCode:
                    print(index[1]+" was added/taken by "+index[0]+" with the amount of "+index[2]+" at "+index[3])
        elif choice == "4":
            ChoiceSearch = True
        else :
            print("Incorrect Choice")

def printInv():
    file = open("ppe.txt","r").readlines()
    print_inven = False
    while print_inven == False:
        print("""
    ( 1 ) Print Inventory In Ascending Order
    ( 2 ) Print inventory for items Less Than 25 boxes 
    ( 3 ) Back
        """)
        choice = input("Enter your Choice: ")
        if choice == "1":
            newfile = []
            for index in file :
                index = index.strip().split(",")
                newfile.append(index)
            newfile = sorted(newfile, key = lambda number: int(number[2]),reverse = False)
            for index in newfile:
                    print(index[0] + ": " + index[2])
                    print_inven = True
        elif choice == "2":
            for index in file:
                index = index.strip().split(",")
                if int(index[2]) <= 25:
                    print (index[0] + ": " + index[2])
                print_inven = True
        elif choice == "3":
            print_inven = True
        else :
            print ("incorrect Choice")
            print_inven = False
def MainMenu():
    mainLoop = False
    while mainLoop == False:
        print("""
        ( 1 )Update Inventory
        ( 2 )Search
        ( 3 )Print Inventory Report
        ( 4 )Exit
        """)
        correctChoice = False 
        while correctChoice == False:
            choice = input("Please enter your choice: ")
            if choice == "1" or choice == "2" or choice == "3" or choice == "4":
                correctChoice = True
            else:
                print("Incorrect Choice!")
        if choice == "1":
            update()
        elif choice == "2":
            search()
        elif choice == "3":
            printInv()
        elif choice == "4":
            print("Out Of The Program...")
            mainLoop = True

MainMenu()